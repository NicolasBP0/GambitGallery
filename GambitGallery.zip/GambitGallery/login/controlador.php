<?php

$servername = "localhost";
$username = "root";
$password = "";
$database = "gambitgallery";

$conexion = new mysqli($servername, $username, $password, $database);

if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}

if (!empty($_POST["login"])) {
    if (empty($_POST["usuario"]) || empty($_POST["pswd"])) {
        echo '<div class="alert alert-danger">Los campos están vacíos.</div>';
    } else {
        $usuario = $_POST["usuario"];
        $clave = $_POST["pswd"];

        $sql = $conexion->prepare("SELECT * FROM users WHERE email = ?");
        $sql->bind_param("s", $usuario);
        $sql->execute();
        $result = $sql->get_result();

        if ($datos = $result->fetch_object()) {
            // Verificar la contraseña utilizando password_verify
            if (password_verify($clave, $datos->pswd)) {
                header("location:index.html");
            } else {
                echo '<div class="alert alert-danger">Contraseña incorrecta.</div>';
            }
        } else {
            echo '<div class="alert alert-danger">El usuario no existe.</div>';
        }

        $sql->close();
    }
}

$conexion->close();
?>
