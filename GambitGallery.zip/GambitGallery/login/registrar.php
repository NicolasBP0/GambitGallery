<?php

$servername = "localhost";
$username = "root";
$password = "";
$database = "gambitgallery";

$conexion = new mysqli($servername, $username, $password, $database);

if ($conexion->connect_error) {
    die("Conexión fallida: " . $conexion->connect_error);
}

if (isset($_POST["registro"])) {
    $reg_nombre = $_POST["reg_nombre"];
    $reg_apellido = $_POST["reg_apellido"];
    $reg_username = $_POST["reg_username"];
    $reg_usuario = $_POST["reg_usuario"];
    $reg_pswd = $_POST["reg_pswd"];

    $hashed_password = password_hash($reg_pswd, PASSWORD_DEFAULT);

    $sql_insert = $conexion->prepare("INSERT INTO users (nombre, apellido, username, email, pswd) VALUES (?, ?, ?, ?, ?)");
    $sql_insert->bind_param("sssss", $reg_nombre, $reg_apellido, $reg_username, $reg_usuario, $hashed_password);

    if ($sql_insert->execute()) {
        // Redirigir después de registrar el usuario correctamente
        header("Location: index.html");
        exit();
    } else {
        echo '<div class="alert alert-danger">Error al registrar el usuario.</div>';
    }

    $sql_insert->close();
}

$conexion->close();

?>

